import bodyParser from "body-parser";
import express from "express";

import * as path from "path";

const app = express();
app.use(bodyParser.json()); // to parse request.body's json
const port = 8080; // default port to listen

// define a route handler for the default home page
app.get("/", ( req, res ) => {
    res.sendFile(path.join(__dirname + "/index.html"));
});

app.post("/api/v1/parse", (request, response) => {
const reqData: string = request.body.data;
const reqDataSet: string[] = reqData.split(/[0]+/);

const firstName: string = reqDataSet[0];
const lastName: string = reqDataSet[1];
const clientId: string = reqDataSet[2];

// send endpoint 1 response
response.send(JSON.stringify ({data: {firstName, lastName, clientId}}));
});

app.post("/api/v2/parse", (request, response) => {
const reqData: string = request.body.data;
const reqDataSet: string[] = reqData.split(/[0]+/);

const firstName: string = reqDataSet[0];
const lastName: string = reqDataSet[1];
const clientId: string = reqDataSet[2].replace(/(\d{3})(\d{4})/, "$1-$2");

// send endpoint 2 response
response.send(JSON.stringify ({data: {firstName, lastName, clientId}}));
});

// start the Express server
app.listen( port, () => {
    // tslint:disable-next-line:no-console
    console.log( `server started at http://localhost:${ port }` );
} );
